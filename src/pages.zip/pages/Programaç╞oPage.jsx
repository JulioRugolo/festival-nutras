// src/pages/HomePage.js
import React from 'react';
import ProgramacaoPage from './ProgramaçãoPage';

const ProgramacãoPage = () => {
  return (
    <div>
      <h1>Bem-vindo ao Nutras</h1>
      {/* Adicione o conteúdo da página inicial aqui */}
    </div>
  );
};

export default ProgramacãoPage;
