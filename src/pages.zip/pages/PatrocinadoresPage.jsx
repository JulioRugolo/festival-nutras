// src/pages/HomePage.js
import React from 'react';

const PatrocinadoresPage = () => {
  return (
    <div>
      <h1>Bem-vindo ao Nutras</h1>
      {/* Adicione o conteúdo da página inicial aqui */}
    </div>
  );
};

export default PatrocinadoresPage;
